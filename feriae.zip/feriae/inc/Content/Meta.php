<?php
/**
 * Registered post meta.
 *
 * @package Feriae
 */

namespace Feriae\Content;

/**
 * Registers event, venue, and organizer meta so it is typed, sanitised, and
 * editable over REST (which the editor sidebar uses).
 */
final class Meta {

	public function __construct( private \Feriae\Settings $settings ) {}

	public const DATETIME_FORMAT = 'Y-m-d H:i:s';

	/** Keys whose change requires regenerating occurrences. */
	public const SCHEDULE_KEYS = array( '_feriae_start', '_feriae_end', '_feriae_timezone', '_feriae_all_day', '_feriae_hide_from_listings', '_feriae_recurrence', '_feriae_status', '_feriae_date_status' );

	public function register(): void {
		// After every post type (ours and other plugins') is registered, so revision support can be checked.
		add_action( 'init', array( $this, 'register_meta' ), 50 );
	}

	/**
	 * @return array<string, array<string, mixed>> Meta key => register_post_meta args.
	 */
	public static function event_fields(): array {
		return array(
			'_feriae_start'              => array(
				'type'              => 'string',
				'sanitize_callback' => array( self::class, 'sanitize_datetime' ),
			),
			'_feriae_end'                => array(
				'type'              => 'string',
				'sanitize_callback' => array( self::class, 'sanitize_datetime' ),
			),
			'_feriae_timezone'           => array(
				'type'              => 'string',
				'sanitize_callback' => array( self::class, 'sanitize_timezone' ),
			),
			'_feriae_all_day'            => array( 'type' => 'boolean' ),
			'_feriae_venue_id'           => array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			),
			'_feriae_organizer_ids'      => array(
				'type'         => 'array',
				'default'      => array(),
				'show_in_rest' => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'integer' ),
					),
				),
			),
			'_feriae_cost'               => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'_feriae_currency_symbol'    => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'_feriae_url'                => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
			'_feriae_featured'           => array( 'type' => 'boolean' ),
			'_feriae_hide_from_listings' => array( 'type' => 'boolean' ),
			// Scheduled, cancelled, or postponed, with an optional note; see EventStatus.
			'_feriae_status'             => array(
				'type'              => 'string',
				'default'           => EventStatus::SCHEDULED,
				'sanitize_callback' => array( EventStatus::class, 'sanitize' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type' => 'string',
						'enum' => EventStatus::ALL,
					),
				),
			),
			'_feriae_status_reason'      => array(
				'type'              => 'string',
				'sanitize_callback' => array( EventStatus::class, 'sanitize_reason' ),
			),
			// One date of a repeating event cancelled or postponed on its own.
			'_feriae_date_status'        => array(
				'type'              => 'array',
				'default'           => array(),
				'sanitize_callback' => array( EventStatus::class, 'sanitize_dates' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'date'   => array(
									'type'    => 'string',
									'pattern' => '^\\d{4}-\\d{2}-\\d{2}$',
								),
								'status' => array(
									'type' => 'string',
									'enum' => array( EventStatus::CANCELLED, EventStatus::POSTPONED ),
								),
								'reason' => array( 'type' => 'string' ),
							),
						),
					),
				),
			),
			// Extra labelled details shown in the event details (imported TEC Pro additional fields).
			'_feriae_details'            => array(
				'type'              => 'array',
				'default'           => array(),
				'sanitize_callback' => array( self::class, 'sanitize_details' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'label' => array( 'type' => 'string' ),
								'value' => array( 'type' => 'string' ),
							),
						),
					),
				),
			),
		);
	}

	/**
	 * @return array<string, array<string, mixed>>
	 */
	public static function venue_fields(): array {
		$text = array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
		);
		return array(
			'_feriae_address'     => $text,
			'_feriae_city'        => $text,
			'_feriae_region'      => $text,
			'_feriae_postal_code' => $text,
			'_feriae_country'     => $text,
			'_feriae_phone'       => $text,
			'_feriae_website'     => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
			// Strings so "not set" can be stored as empty rather than 0,0.
			'_feriae_lat'         => array(
				'type'              => 'string',
				'sanitize_callback' => array( self::class, 'sanitize_coordinate' ),
			),
			'_feriae_lng'         => array(
				'type'              => 'string',
				'sanitize_callback' => array( self::class, 'sanitize_coordinate' ),
			),
		);
	}

	/**
	 * @return array<string, array<string, mixed>>
	 */
	public static function organizer_fields(): array {
		return array(
			'_feriae_phone'   => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'_feriae_email'   => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_email',
			),
			'_feriae_website' => array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
			),
		);
	}

	public function register_meta(): void {
		$groups = array(
			PostTypes::VENUE     => self::venue_fields(),
			PostTypes::ORGANIZER => self::organizer_fields(),
		);
		foreach ( $this->settings->event_post_types() as $post_type ) {
			$groups[ $post_type ] = self::event_fields();
		}

		foreach ( $groups as $post_type => $fields ) {
			/**
			 * Filters the meta fields registered for a plugin post type. Add-ons can
			 * add fields here to get REST exposure and sanitisation for free.
			 *
			 * @param array  $fields    Meta key => register_post_meta args.
			 * @param string $post_type Post type.
			 */
			$fields = apply_filters( 'feriae/meta_fields', $fields, $post_type );

			// Track event dates and details in revisions where the post type keeps them.
			$revisions = in_array( $post_type, $this->settings->event_post_types(), true ) && post_type_supports( $post_type, 'revisions' );

			foreach ( $fields as $key => $args ) {
				if ( $revisions ) {
					$args += array( 'revisions_enabled' => true );
				}
				register_post_meta(
					$post_type,
					$key,
					array_merge(
						array(
							'single'        => true,
							'show_in_rest'  => true,
							// Underscore keys are protected; grant access to anyone who can edit the post.
							'auth_callback' => static fn( $allowed, $meta_key, $post_id ) => current_user_can( 'edit_post', $post_id ),
						),
						$args
					)
				);
			}
		}
	}

	/**
	 * @return array<int, array{label: string, value: string}>
	 */
	public static function sanitize_details( mixed $value ): array {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$label = trim( sanitize_text_field( (string) ( $row['label'] ?? '' ) ) );
			$text  = trim( sanitize_textarea_field( (string) ( $row['value'] ?? '' ) ) );
			if ( '' !== $label && '' !== $text ) {
				$out[] = array(
					'label' => $label,
					'value' => $text,
				);
			}
		}
		return $out;
	}

	/**
	 * Accepts "Y-m-d H:i:s", "Y-m-d\TH:i:s", or "Y-m-d H:i" and stores "Y-m-d H:i:s".
	 */
	public static function sanitize_datetime( mixed $value ): string {
		$value = trim( str_replace( 'T', ' ', (string) $value ) );
		if ( '' === $value ) {
			return '';
		}
		foreach ( array( self::DATETIME_FORMAT, 'Y-m-d H:i', 'Y-m-d' ) as $format ) {
			$date = \DateTimeImmutable::createFromFormat( '!' . $format, $value );
			if ( $date && $date->format( $format ) === $value ) {
				return $date->format( self::DATETIME_FORMAT );
			}
		}
		return '';
	}

	public static function sanitize_coordinate( mixed $value ): string {
		return is_numeric( $value ) ? (string) (float) $value : '';
	}

	public static function sanitize_timezone( mixed $value ): string {
		$value = (string) $value;
		return in_array( $value, timezone_identifiers_list(), true ) ? $value : '';
	}
}
