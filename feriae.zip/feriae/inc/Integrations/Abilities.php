<?php
/**
 * Abilities API.
 *
 * @package Feriae
 */

namespace Feriae\Integrations;

use Feriae\Content\EventStatus;
use Feriae\Content\Meta;
use Feriae\Occurrences\Repository;
use Feriae\Rest\OccurrencesController;
use WP_Error;

/**
 * Registers event abilities so AI assistants, automation tools, and other
 * plugins get a typed, permission-checked interface (also exposed at
 * /wp-json/wp-abilities/v1).
 */
final class Abilities {

	private const CATEGORY = 'feriae';

	public function __construct( private OccurrencesController $presenter ) {}

	public function register(): void {
		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	public function register_category(): void {
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => __( 'Events', 'feriae' ),
				'description' => __( 'Find, read, and create calendar events.', 'feriae' ),
			)
		);
	}

	public function register_abilities(): void {
		$occurrence_schema = array(
			'type'       => 'object',
			'properties' => array(
				'id'        => array( 'type' => 'integer' ),
				'event_id'  => array( 'type' => 'integer' ),
				'title'     => array( 'type' => 'string' ),
				'link'      => array( 'type' => 'string' ),
				'start'     => array( 'type' => 'string', 'format' => 'date-time' ),
				'end'       => array( 'type' => 'string', 'format' => 'date-time' ),
				'timezone'  => array( 'type' => 'string' ),
				'all_day'   => array( 'type' => 'boolean' ),
				'status'    => array(
					'type' => 'string',
					'enum' => EventStatus::ALL,
				),
				'status_reason' => array( 'type' => 'string' ),
				'cost'      => array( 'type' => 'string' ),
			),
		);

		wp_register_ability(
			'feriae/list-events',
			array(
				'label'               => __( 'List events', 'feriae' ),
				'description'         => __( 'Lists published events. Without dates, returns upcoming events soonest first.', 'feriae' ),
				'category'            => self::CATEGORY,
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'start'      => array(
							'type'        => 'string',
							'format'      => 'date',
							'description' => __( 'First day (Y-m-d) of a date range.', 'feriae' ),
						),
						'end'        => array(
							'type'        => 'string',
							'format'      => 'date',
							'description' => __( 'Last day (Y-m-d) of a date range, inclusive.', 'feriae' ),
						),
						'past'       => array(
							'type'        => 'boolean',
							'description' => __( 'Return past events, newest first.', 'feriae' ),
						),
						'search'     => array( 'type' => 'string' ),
						'categories' => array(
							'type'  => 'array',
							'items' => array( 'type' => 'integer' ),
						),
						'limit'      => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 20,
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'  => 'array',
					'items' => $occurrence_schema,
				),
				'execute_callback'    => array( $this, 'list_events' ),
				'permission_callback' => '__return_true', // Published data only.
				'meta'                => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		wp_register_ability(
			'feriae/create-event',
			array(
				'label'               => __( 'Create event', 'feriae' ),
				'description'         => __( 'Creates an event. Saved as a draft unless status is "publish" and the user can publish.', 'feriae' ),
				'category'            => self::CATEGORY,
				'input_schema'        => array(
					'type'                 => 'object',
					'required'             => array( 'title', 'start' ),
					'properties'           => array(
						'title'     => array( 'type' => 'string' ),
						'content'   => array( 'type' => 'string' ),
						'start'     => array(
							'type'        => 'string',
							'description' => __( 'Local start, "Y-m-d H:i" in the event timezone.', 'feriae' ),
						),
						'end'       => array( 'type' => 'string' ),
						'all_day'   => array( 'type' => 'boolean' ),
						'timezone'  => array(
							'type'        => 'string',
							'description' => __( 'IANA timezone. Defaults to the site timezone.', 'feriae' ),
						),
						'venue_id'  => array( 'type' => 'integer' ),
						'post_type' => array(
							'type' => 'string',
							'enum' => feriae_event_post_types(),
						),
						'status'    => array(
							'type'    => 'string',
							'enum'    => array( 'draft', 'publish' ),
							'default' => 'draft',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'id'       => array( 'type' => 'integer' ),
						'edit_url' => array( 'type' => 'string' ),
						'link'     => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'create_event' ),
				'permission_callback' => static function ( $input ): bool {
					$type   = get_post_type_object( (string) ( $input['post_type'] ?? feriae_event_post_types()[0] ?? '' ) );
					return $type && current_user_can( $type->cap->edit_posts );
				},
				'meta'                => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);

		wp_register_ability(
			'feriae/set-event-status',
			array(
				'label'               => __( 'Cancel or postpone an event', 'feriae' ),
				'description'         => __( 'Marks an event, or one date of a repeating event, as cancelled, postponed, or scheduled again, with an optional note shown to visitors. Bookings close while it is cancelled or postponed.', 'feriae' ),
				'category'            => self::CATEGORY,
				'input_schema'        => array(
					'type'                 => 'object',
					'required'             => array( 'event_id', 'status' ),
					'properties'           => array(
						'event_id' => array( 'type' => 'integer' ),
						'status'   => array(
							'type' => 'string',
							'enum' => EventStatus::ALL,
						),
						'reason'   => array(
							'type'        => 'string',
							'maxLength'   => 500,
							'description' => __( 'Optional note for visitors, such as the reason.', 'feriae' ),
						),
						'date'     => array(
							'type'        => 'string',
							'format'      => 'date',
							'description' => __( 'One date (Y-m-d) of a repeating event; omit for the whole event.', 'feriae' ),
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'event_id' => array( 'type' => 'integer' ),
						'status'   => array( 'type' => 'string' ),
						'date'     => array( 'type' => 'string' ),
						'link'     => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => array( $this, 'set_event_status' ),
				'permission_callback' => static fn( $input ): bool => current_user_can( 'edit_post', (int) ( ( (array) $input )['event_id'] ?? 0 ) ),
				'meta'                => array(
					'show_in_rest' => true,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * @param array<string, mixed> $input Validated input.
	 * @return array<int, array<string, mixed>>
	 */
	public function list_events( $input = array() ): array {
		$input = (array) $input;
		$args  = array(
			'search'     => (string) ( $input['search'] ?? '' ),
			'categories' => (array) ( $input['categories'] ?? array() ),
			'per_page'   => (int) ( $input['limit'] ?? 20 ),
		);
		if ( ! empty( $input['start'] ) ) {
			$args['local_from'] = $input['start'] . ' 00:00:00';
			$args['local_to']   = ( $input['end'] ?? $input['start'] ) . ' 23:59:59';
		} elseif ( ! empty( $input['past'] ) ) {
			$args['ends_before'] = Repository::now();
			$args['order']       = 'DESC';
		} else {
			$args['ends_after'] = Repository::now();
		}
		return array_map( array( $this->presenter, 'prepare_item' ), feriae_get_occurrences( $args )['items'] );
	}

	/**
	 * @param array<string, mixed> $input Validated input.
	 * @return array<string, mixed>|WP_Error
	 */
	public function create_event( $input ) {
		$input     = (array) $input;
		$post_type = (string) ( $input['post_type'] ?? feriae_event_post_types()[0] ?? '' );
		$type      = get_post_type_object( $post_type );
		if ( ! $type ) {
			return new WP_Error( 'feriae_no_event_type', __( 'No event post type is enabled.', 'feriae' ) );
		}

		$start = Meta::sanitize_datetime( $input['start'] ?? '' );
		if ( '' === $start ) {
			return new WP_Error( 'feriae_invalid_start', __( 'Start must be a date like "2026-11-03 19:00".', 'feriae' ) );
		}
		$end = Meta::sanitize_datetime( $input['end'] ?? '' ) ?: $start;

		$status = ( 'publish' === ( $input['status'] ?? '' ) && current_user_can( $type->cap->publish_posts ) ) ? 'publish' : 'draft';

		$id = wp_insert_post(
			array(
				'post_type'    => $post_type,
				'post_title'   => sanitize_text_field( (string) $input['title'] ),
				'post_content' => wp_kses_post( (string) ( $input['content'] ?? '' ) ),
				'post_status'  => $status,
				'meta_input'   => array(
					'_feriae_start'    => $start,
					'_feriae_end'      => $end,
					'_feriae_all_day'  => ! empty( $input['all_day'] ),
					'_feriae_timezone' => Meta::sanitize_timezone( $input['timezone'] ?? '' ),
					'_feriae_venue_id' => absint( $input['venue_id'] ?? 0 ),
				),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		return array(
			'id'       => $id,
			'edit_url' => (string) get_edit_post_link( $id, 'raw' ),
			'link'     => (string) get_permalink( $id ),
		);
	}

	/**
	 * @param array<string, mixed> $input Validated input.
	 * @return array<string, mixed>|WP_Error
	 */
	public function set_event_status( $input ) {
		$input    = (array) $input;
		$event_id = (int) $input['event_id'];
		$date     = (string) ( $input['date'] ?? '' );
		$result   = EventStatus::set( $event_id, (string) $input['status'], (string) ( $input['reason'] ?? '' ), $date );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$occurrence = '' !== $date ? feriae()->occurrences()->on_date( $event_id, $date ) : null;
		return array(
			'event_id' => $event_id,
			'status'   => (string) $input['status'],
			'date'     => $date,
			'link'     => $occurrence ? feriae_occurrence_url( $occurrence ) : (string) get_permalink( $event_id ),
		);
	}
}
