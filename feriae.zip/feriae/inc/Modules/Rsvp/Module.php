<?php
/**
 * RSVP module.
 *
 * @package Feriae
 */

namespace Feriae\Modules\Rsvp;

use Feriae\Attendance\Schema;
use Feriae\Content\Event;
use Feriae\Modules\AbstractModule;
use Feriae\Occurrences\Occurrence;

use const Feriae\PLUGIN_DIR;
use const Feriae\PLUGIN_FILE;

/**
 * Free RSVPs: settings in the editor, a form in event details, confirmation
 * emails with a private change/cancel link, and an attendee list.
 */
final class Module extends AbstractModule {

	private Service $service;

	public function __construct() {
		$this->service = new Service();
	}

	public function id(): string {
		return 'rsvp';
	}

	public function label(): string {
		return __( 'RSVP', 'feriae' );
	}

	public function description(): string {
		return __( 'Free RSVPs with capacity limits, guests, confirmation emails, an attendee list with CSV export, and check-in.', 'feriae' );
	}

	public function install(): void {
		Schema::install();
	}

	public function boot(): void {
		Schema::maybe_install();
		\Feriae\Attendance\WaitlistService::register();
		\Feriae\Attendance\FieldSets::register();

		add_filter( 'feriae/meta_fields', array( $this, 'meta_fields' ), 10, 2 );
		add_action( 'added_post_meta', array( $this, 'on_meta_change' ), 10, 3 );
		add_action( 'updated_post_meta', array( $this, 'on_meta_change' ), 10, 3 );
		add_action( 'deleted_post_meta', array( $this, 'on_meta_change' ), 10, 3 );

		add_filter( 'feriae/event_details/sections', array( $this, 'section' ), 10, 3 );
		add_action( 'init', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_on_event_pages' ) );
		add_action( 'admin_post_feriae_rsvp', array( $this, 'handle_form' ) );
		add_action( 'admin_post_nopriv_feriae_rsvp', array( $this, 'handle_form' ) );
		add_filter( 'wp_robots', array( $this, 'robots' ) );
		add_action( 'template_redirect', array( $this, 'no_cache_private_links' ) );

		( new Rest( $this->service ) )->register();
		if ( is_admin() ) {
			( new Admin( $this->service ) )->register();
		}
		add_action( 'feriae/uninstall', array( Schema::class, 'uninstall' ) );
	}

	/**
	 * Registers the _feriae_rsvp settings object on every event post type.
	 *
	 * @param array<string, array<string, mixed>> $fields    Meta fields.
	 * @param string                              $post_type Post type.
	 * @return array<string, array<string, mixed>>
	 */
	public function meta_fields( array $fields, string $post_type ): array {
		if ( ! in_array( $post_type, feriae_event_post_types(), true ) ) {
			return $fields;
		}
		$fields[ Service::META_KEY ] = array(
			'type'              => 'object',
			'default'           => Service::defaults(),
			'sanitize_callback' => array( self::class, 'sanitize_config' ),
			'show_in_rest'      => array(
				'schema' => array(
					'type'                 => 'object',
					'properties'           => array(
						'enabled'          => array( 'type' => 'boolean' ),
						'capacity'         => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'max_per_response' => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 20,
						),
						'deadline'         => array( 'type' => 'string' ),
						'allow_not_going'  => array( 'type' => 'boolean' ),
						'show_count'       => array( 'type' => 'boolean' ),
						'waitlist'         => array( 'type' => 'boolean' ),
						'attendee_details' => array(
							'type' => 'string',
							'enum' => \Feriae\Attendance\Fields::DETAILS,
						),
						'fields'           => \Feriae\Attendance\Fields::schema(),
					),
					'additionalProperties' => false,
				),
			),
		);
		return $fields;
	}

	/**
	 * @param mixed $value Raw meta value.
	 * @return array<string, mixed>
	 */
	public static function sanitize_config( mixed $value ): array {
		$value    = is_array( $value ) ? $value : array();
		$defaults = Service::defaults();
		return array(
			'enabled'          => ! empty( $value['enabled'] ),
			'capacity'         => max( 0, (int) ( $value['capacity'] ?? 0 ) ),
			'max_per_response' => max( 1, min( 20, (int) ( $value['max_per_response'] ?? $defaults['max_per_response'] ) ) ),
			'deadline'         => \Feriae\Content\Meta::sanitize_datetime( $value['deadline'] ?? '' ),
			'allow_not_going'  => (bool) ( $value['allow_not_going'] ?? $defaults['allow_not_going'] ),
			'show_count'       => (bool) ( $value['show_count'] ?? $defaults['show_count'] ),
			'waitlist'         => ! empty( $value['waitlist'] ),
			'attendee_details' => \Feriae\Attendance\Fields::sanitize_details( $value['attendee_details'] ?? 'none' ),
			'fields'           => \Feriae\Attendance\Fields::sanitize( $value['fields'] ?? array() ),
		);
	}

	/**
	 * @param int|int[] $meta_ids Meta id(s); unused.
	 */
	public function on_meta_change( int|array $meta_ids, int $post_id, string $meta_key ): void {
		// The deadline is stored in event-local time, so a timezone change moves it too.
		if ( in_array( $meta_key, array( Service::META_KEY, '_feriae_timezone' ), true ) && Event::is_event_type( (string) get_post_type( $post_id ) ) ) {
			$this->service->sync( $post_id );
		}
	}

	public function register_assets(): void {
		$asset_file = PLUGIN_DIR . '/build/modules/rsvp/view.asset.php';
		if ( is_readable( $asset_file ) ) {
			$asset = require $asset_file;
			wp_register_script_module( 'feriae-rsvp', plugins_url( 'build/modules/rsvp/view.js', PLUGIN_FILE ), $asset['dependencies'], $asset['version'] );
		}
	}

	/**
	 * Enqueued in <head> on event pages with RSVP on; the section also enqueues
	 * itself as a fallback when rendered elsewhere.
	 */
	public function enqueue_on_event_pages(): void {
		if ( is_singular( feriae_event_post_types() ) && $this->service->ticket_type( get_queried_object_id() ) ) {
			wp_enqueue_script_module( 'feriae-rsvp' );
		}
	}

	/**
	 * Adds the RSVP form to event details.
	 *
	 * @param string[] $sections Sections.
	 * @return string[]
	 */
	public function section( array $sections, Event $event, Occurrence $occurrence ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display state.
		$token = sanitize_text_field( wp_unslash( $_GET['feriae_rsvp_token'] ?? '' ) );
		$type  = $this->type_for_page( $event->id(), $occurrence, $token );
		if ( $type ) {
			wp_enqueue_script_module( 'feriae-rsvp' );
			$sections['rsvp'] = Form::render( $event, $type, $this->service, $token );
		}
		return $sections;
	}

	/**
	 * The date the form is for: a private link's response or waitlist place
	 * keeps its own date wherever the link opens; otherwise the date shown.
	 */
	private function type_for_page( int $event_id, Occurrence $occurrence, string $token ): ?\Feriae\Attendance\TicketType {
		if ( '' !== $token ) {
			$type = $this->service->response_type( $event_id, $this->service->response_for_token( $token ) );
			if ( $type ) {
				return $type;
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display state.
		$wl_token = sanitize_text_field( wp_unslash( $_GET['feriae_waitlist'] ?? '' ) );
		$entry    = '' !== $wl_token ? ( new \Feriae\Attendance\Waitlist() )->by_token( $wl_token ) : null;
		if ( $entry && $entry->event_id === $event_id ) {
			$type = ( new \Feriae\Attendance\TicketTypes() )->get( $entry->ticket_type_id );
			if ( $type && Service::TYPE_KEY === $type->type_key && 'active' === $type->status ) {
				return $type;
			}
		}
		return $this->service->ticket_type( $event_id, $occurrence->event_id === $event_id ? $occurrence->sequence : 0 );
	}

	/**
	 * No-JS form submission: handle, then redirect back with an outcome code.
	 */
	public function handle_form(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- public form, protected by honeypot, signed timestamp, and rate limit (nonces break on cached pages).
		$event_id = absint( $_POST['event_id'] ?? 0 );
		$input    = array(
			'name'     => wp_unslash( $_POST['name'] ?? '' ),
			'email'    => wp_unslash( $_POST['email'] ?? '' ),
			'status'   => sanitize_key( wp_unslash( $_POST['status'] ?? 'going' ) ),
			'quantity' => absint( $_POST['quantity'] ?? 1 ),
			'sequence' => absint( $_POST['sequence'] ?? 0 ),
			'attendees' => wp_unslash( (array) ( $_POST['attendees'] ?? array() ) ),
			'token'    => sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) ),
			'website'  => wp_unslash( $_POST['website'] ?? '' ),
			'ts'       => sanitize_text_field( wp_unslash( $_POST['ts'] ?? '' ) ),
			'ip'       => self::client_ip(),
		);
		$cancel   = ! empty( $_POST['cancel'] );
		// phpcs:enable

		$result = $cancel ? $this->service->cancel( $input['token'] ) : $this->service->respond( $event_id, $input );
		// Back to the date the form was for.
		$occurrence = feriae()->occurrences()->by_sequence( $event_id, $input['sequence'] );
		$url        = ( $occurrence ? feriae_occurrence_url( $occurrence ) : get_permalink( $event_id ) ) ?: home_url( '/' );
		$args   = array( 'feriae_rsvp' => $result->code );
		if ( ! $result->ok && $input['token'] ) {
			$args['feriae_rsvp_token'] = rawurlencode( $input['token'] );
		}
		wp_safe_redirect( add_query_arg( $args, $url ) . '#rsvp', 303 );
		exit;
	}

	/**
	 * Outcome and private-link URLs are per visitor: keep them out of search
	 * indexes and page caches.
	 *
	 * @param array<string, bool|string> $robots Robots directives.
	 * @return array<string, bool|string>
	 */
	public function robots( array $robots ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['feriae_rsvp'] ) || isset( $_GET['feriae_rsvp_token'] ) ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}

	public function no_cache_private_links(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['feriae_rsvp_token'] ) || isset( $_GET['feriae_rsvp'] ) ) {
			nocache_headers();
		}
	}

	public static function client_ip(): string {
		return \Feriae\Attendance\Guard::client_ip();
	}
}
